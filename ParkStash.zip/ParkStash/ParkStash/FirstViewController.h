//
//  FirstViewController.h
//  ParkStash
//
//  Created by Saketha  on 1/23/18.
//  Copyright © 2018 ParkStash. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CLLocation.h>
#import <CoreLocation/CLAvailability.h>

@interface FirstViewController : UIViewController <UISearchBarDelegate, MKMapViewDelegate>



@end


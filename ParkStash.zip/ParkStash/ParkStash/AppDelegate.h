//
//  AppDelegate.h
//  ParkStash
//
//  Created by Saketha  on 1/23/18.
//  Copyright © 2018 ParkStash. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

